//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
//-----------------------------5-1,Swift2.0 字符串之字符串基础---------------------------
/*
 字符串String
 
 */
var str1: String = "hello playground"
let str2 = String("hello swift")


//空字符串
var emptyString = ""
var emptyString2 = String()

//判断字符串是否为空
str1.isEmpty
emptyString2.isEmpty

let mark = "!!!"

//字符串拼接用+
str + mark

str += mark

//str2 += mark  ❌  常量字符串不可改变

let name = "liuyubobobo"
let  age = 18
let height = 1.78


//字符串插值
let s = "my name is \(name). I am \(age) years old. I am \(height) meters"
print(s)

//let  s3 = "\\"  此写法淘汰❓
//let s4  = "\\""

//-------------------------------5-2,Swift2.0 字符串之Character和Unicode-----------------------


/*
 swift 语言中字符用双引号包裹,区分字符和字符串的关键是显式声明时写上Character(字符)或String(字符串类型)
 */
for c in str.characters
{
    print(c)
}

let mark2: Character = "!"


str + mark

str + String(mark)

str.append(mark)  //改变调用者的值


//❓
//let englishLetter: Character = "a"
//let chineseLetter:Character = "慕"
//
//// control + command + 空格  输入表情
//let dog: Character = "🐶"
//let coolGuy: Character= "\u{1F60E}"



//判断字符串长度
var coolLetters = "abc"
coolLetters.characters.count

var coolLetters2 = "慕课网"
coolLetters2.characters.count

var coolLetters3 = "\u{1F60E}\u{1F60E}\u{1F60E}"
coolLetters3.characters.count


//注音符
var cafe = "cafe"
var cafe2  = "cafe\u{0301}"
cafe.characters.count
cafe2.characters.count

//--------------------------5-3,Swift2.0 字符串之String.index和Range-❓---------------------------
/*
 String.index
 
 s.startIndex
 s.endIndex
 */

let startIndex = str.startIndex
startIndex
str[startIndex]

//str[startIndex.advancedBy(5)] ❓

//let spaceIndex = startIndex.advancedBy(5)


//predecessor 前一个索引的字符  successor后一个索引
//str[spaceIndex.predecessor()]
//str [spaceIndex.successor()]
//
//
////[startIndex,endIndex)
//let endIndex = str.endIndex
//
//str[endIndex.predecessor()]

//------------------------------5-4,swift2.0,字符串之as和NSString---------------------------


//字符串字母全部大写
str.uppercased()

//字符串全部小写
str.lowercased()

//一句话中每一个词的首字母大写
str.capitalized


//判断字符串是否是原字符串的子串
str.contains("Hello")


//判断一个字符串是否调用字符串的前缀
str.hasPrefix("He")

//判断一个字符串是否调用字符串的后缀
str.hasSuffix("ft")




let s1 = "one third is \(1.0/3.0)"

//NSString 可以被强制转换为String

// NSString

let s2 = NSString(format:"one third is %.2f",1.0/3.0)

// String
let s3: String = NSString(format:"one third is %.2f",1.0/3.0) as String


var s4: NSString = "one third is 0.33"


//获得一个子串从某一个位置开始到结束
s4 .substring(from: 4)

//获得一个子串从头开始到某一位置结束
s4.substring(to: 4)


// 4表示位置,5表示长度
s4.substring(with: NSMakeRange(4, 5))


let s5 = "😀😀😀"
let s6: NSString = "😀😀😀"

//String长度
s5.characters.count
//NSString 长度
s6.length



//去除字符串中冗余字符
let s7 = "  -----------hello----------  " as NSString
//s7.trimmingCharacters(in: CharacterSet(charactersInSting:""))

s7.trimmingCharacters(in: CharacterSet(charactersIn:" -"))


//-------------------------------------5,5 Swift2.0 字符串之文档查询---------------------------------------------


// option 查询




































































